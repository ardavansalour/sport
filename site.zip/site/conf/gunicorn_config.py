command = '/root/django_env/bin/gunicorn'
pythonpath = '/root/familytree'
bind = '165.22.49.20:8000'
workers = 2
